CREATE SCHEMA ecommerce_db;

CREATE TABLE `ecommerce_db`.`tbl_product` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NOT NULL,
  `price` FLOAT NOT NULL,
  PRIMARY KEY (`id`));

INSERT INTO `ecommerce_db`.`tbl_product` (`id`, `name`, `price`) VALUES ('1', 'tv', '200');
