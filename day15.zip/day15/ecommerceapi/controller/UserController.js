let users = []

export function registerUser(req,res){
    users.push(req.body)
    res
    .status(201)
    .send('Registration success')
}
export function authenticate(req,res){
    const requestedUser = req.body;
    const foundUser = users.find( user => user.username ==  requestedUser.username 
                                            && user.password == requestedUser.password)
    if(foundUser){
        const authenticatedUser = {username:foundUser.username}
        res.send(authenticatedUser)
    }
    else{
        res.status(404).send({message:'bad credentials'})
    }
}
export function showAllUsers(req,res){
    res
    .status(200)
    .send(users)
}