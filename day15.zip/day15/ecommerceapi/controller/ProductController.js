import { findAll,deleteById } from "../model/ProductModel.js"
//let products = [{id:1,name:'tv',price:100},{id:2,name:'phone',price:200}]
let products = []

export async function showAllProducts(req,res){
    products = await findAll();
    console.log(products)
    res.send(products)
}

export function showProductById(req,res){
    const foundProduct = products.find( p => p.id ==  req.params.productId )
    if(foundProduct)
        res.send(foundProduct)
    else{
        res
            .status(404)
            .send({message:"Product with id " + req.params.productId +" does NOT exist" })
    }
}

export function deleteProductById(req,res) {

    const productTobeDeleted = req.params.productId;
    
    if(deleteById(productTobeDeleted)){
        products = products.filter( p => p.id != productTobeDeleted)
        res
        .status(204)
        .send()
    }
    else{
        res.send({message:'product not deleted'})
    }
 }

 export function createNewProduct(req,res){
    products.push(req.body)
    res
    .status(201)
    .send(req.body);
}