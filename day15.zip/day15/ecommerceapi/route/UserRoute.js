import express from "express";
import { authenticate, registerUser, showAllUsers } from "../controller/UserController.js";
const userRouter = express.Router();

userRouter.post('/register',registerUser)
userRouter.post('/authenticate',authenticate)
userRouter.get('',showAllUsers)

export default userRouter