import { body, validationResult } from "express-validator"

const validation = (req,res,next)=>{

    console.log('pre-prosessing validation ')
    const errors =  validationResult(req)
    console.log(errors.isEmpty())
    console.log(errors)
    if(!errors.isEmpty()){
        return res.status(400).send({message:errors}) //if not show error    
    }
    else
    {
        next();//if yes allow
     
    }
    console.log('post-prosessing validation ')

}

export default validation