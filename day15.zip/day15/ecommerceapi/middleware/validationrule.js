import { body } from "express-validator";

const validationrule = [
    body('name').notEmpty().withMessage('MUST')
                .isLength({min:5}).withMessage('length')
]

export default validationrule