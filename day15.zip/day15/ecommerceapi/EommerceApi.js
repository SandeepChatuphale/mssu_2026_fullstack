import express, { json } from "express";
import cors from 'cors'
import productRouter from "./route/ProductRoute.js";
import userRouter from "./route/UserRoute.js";
import logging from "./middleware/logging.js";
import validation from "./middleware/validation.js";
import validationrule from "./middleware/validationrule.js";
const app = express();

app.use(cors())
app.use(json())
app.use(logging)

app.use(validationrule)
app.use(validation)

app.use('/products',productRouter)
app.use('/users',userRouter)


app.listen(8080,()=>console.log('server running on 8080'))