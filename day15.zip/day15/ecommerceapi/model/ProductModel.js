import pool from "../config/db.js";
export const findAll=async()=>{
    const sql = 'SELECT * FROM tbl_product';
    const [products] = await pool.query(sql);
    return products;
}

export const deleteById = async(id)=>{
    const sql = 'DELETE FROM tbl_product WHERE id = ?'
    const product = await pool.query(sql,[id])
    console.log(product.affectedRows)
    return product.affectedRows == 1
}