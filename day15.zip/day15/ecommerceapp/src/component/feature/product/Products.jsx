import { useContext, useState } from "react";
import ProductFilter from "./ProductFilter";
import { CartContext } from "../../../context/CartProvider";
import deleteImg from '../../../assets/deleteImg.png'
import { ProductContext } from "../../../context/ProductProvider";

const Products = () =>{

    let {original,deleteProductById} = useContext(ProductContext)
    const [products,setProducts] = useState(original)
   
    const {addToCart} = useContext(CartContext)
    

    const handleProductFiltering = (criteria) =>{
       // alert(criteria)
        //filter products based on user selection
        if(criteria === 'cheaper'){
           let sorted = products.sort((p1,p2) => p1.price - p2.price)
           setProducts([...sorted])
        }
        else if(criteria === 'expensive'){
             let sorted = products.sort((p1,p2) => p2.price - p1.price)
             setProducts([...sorted])
        }
        else {}     
    }
    const deleteProduct = (id) => {
       const confirmation = confirm('are you sure to delete ' + id)
       if(confirmation){
        deleteProductById(id)
        setProducts(products.filter( p => p.id !=id ))
       }  
    }
    //use map() function
    const product = products.map( p => {
        return(
            <tr key={p.id}>
                <td>{p.id}</td>
                <td>{p.name}</td>
                <td>{p.price}</td>
                <td>
                    <button onClick={ () => addToCart(p)   }>Add to cart</button>
                    <button onClick={ () => deleteProduct(p.id)  }><img src={deleteImg} width={25} height={25}></img> </button>
                </td>
            </tr>
        )
    })
    if(products.length > 0){
    return (<>
    <ProductFilter type={handleProductFiltering}></ProductFilter>
    <table>
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Name</th>
                    <th>Price</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
                    {product}
                </tbody>
    </table></> )
    }
    else{
        return <h2>Out of Stock</h2>
    }
}
export default Products
