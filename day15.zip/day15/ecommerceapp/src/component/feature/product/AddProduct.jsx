import { useState } from "react";

const AddProduct = ()=>{

    const [product,setProduct] = useState({name:'',price:0});

    const handleFormSubmission = (e)=>{
        e.preventDefault();
        console.log(product)
    }

    return(
        <>
            <form onSubmit={handleFormSubmission}>
                <input type="text" placeholder="Name" onChange={ (e) => setProduct({...product,name:e.target.value})  }/>
                <input type="number" placeholder="Price" onChange={ (e) => setProduct({...product,price:e.target.value})  }/>
                <input type="submit"/>
            </form>
        </>
    )

}

export default AddProduct