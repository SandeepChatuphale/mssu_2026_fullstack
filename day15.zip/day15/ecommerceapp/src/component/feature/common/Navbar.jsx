import { useContext } from "react"
import { Link } from "react-router-dom"
import { AuthContext } from "../../../context/AuthProvider"
import { CartContext } from "../../../context/CartProvider"

const Navbar = () =>{

    const {isLoggedIn} = useContext(AuthContext)
    const {cart} = useContext(CartContext)

    return(
        <ul>
            { !isLoggedIn && <><li><Link to="login">Login</Link> </li>
                               <li><Link to='register'>Register</Link>  </li>
                             </>
            }
            <li><Link to="products">Products</Link> </li>
            { 
             isLoggedIn && <>
             <li><Link to="cart/sachin">Cart { cart.length > 0 && <>You have { cart.length } items </> } </Link> </li>
             <li><Link to="logout" replace>Logout</Link>  </li> </>
            }
        </ul>
    )
}

export default Navbar