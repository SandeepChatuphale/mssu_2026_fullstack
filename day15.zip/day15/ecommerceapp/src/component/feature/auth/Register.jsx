import { useContext, useState } from "react"
import { AuthContext } from "../../../context/AuthProvider";

const Register = () =>{

    const [username,setUsername] = useState('')
    const [password,setPassword] = useState('')

    const {register} = useContext(AuthContext);

    const handleFormSubmission = (e) =>{
        e.preventDefault(); //prevent default event 
        //in our case form submission event

        register(username,password)
    }

    const registerjsx = <form onSubmit={ (e) => handleFormSubmission(e) }>
        <input type="text" placeholder="Username" autoComplete="username"
              onChange={ (e) => setUsername(e.target.value)}/><br/>
        <input type="password" placeholder="Password" autoComplete="password"
                               onChange={(e) => setPassword(e.target.value)}/><br/>
        <input type="submit"/>
    </form>

    return(
       <>{registerjsx}</>   
    )
}

export default Register