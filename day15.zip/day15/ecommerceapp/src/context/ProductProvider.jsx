import { createContext, useEffect, useState } from "react";

export const ProductContext = createContext();

const ProductProvider = (props) => {

    const [original,setOriginal] = useState([])

    async function fetchProducts(){
       const result = await fetch('http://localhost:8080/products');
       const data = await result.json();
       setOriginal(data)
    } 

    const deleteProductById = async(id)=>{
        const result = await fetch('http://localhost:8080/products/'+id,{
            method:'DELETE'
        });
        console.log(result)
    }

     const addProduct = async(p) =>{
        await fetch('',{
            method:'POST',
            body:JSON.stringify(p),
            headers:{'Content-Type':'application/json'}
        })
     }


    useEffect( ()=>{fetchProducts()},[])

    return(
        <ProductContext.Provider value={{original,deleteProductById,addProduct}}>
            {props.children}
        </ProductContext.Provider>
    )
}

export default ProductProvider