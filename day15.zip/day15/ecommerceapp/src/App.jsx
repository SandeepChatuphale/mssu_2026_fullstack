import './App.css'
import Header from './component/feature/common/Header'
import Footer from './component/feature/common/Footer'
import Products from './component/feature/product/Products'
import Login from './component/feature/auth/Login'
import Cart from './component/feature/cart/Cart'
import { BrowserRouter, Routes,Route, Navigate } from 'react-router-dom'
import Navbar from './component/feature/common/Navbar'
import Logout from './component/feature/auth/Logout'
import AuthGuard from './guard/AuthGuard'
import AuthProvider from './context/AuthProvider'
import Register from './component/feature/auth/Register'
import CartProvider from './context/CartProvider'
import ProductProvider from './context/ProductProvider'
import AddProduct from './component/feature/product/AddProduct'

function App() {
  return (
    <>
      <AuthProvider>
        <ProductProvider>
        <CartProvider>
        <BrowserRouter>
          <Header title="MSSU-Mumbai"></Header>
          <Navbar></Navbar>
          <Routes>
            <Route path='login' element={<Login></Login>}></Route>
            <Route path='register' element={<Register></Register> }></Route> 
            <Route path='add' element={<AddProduct></AddProduct> }></Route>  
            <Route path='products' element={<Products></Products>}></Route>  
            <Route path='cart/:name' element={
              <AuthGuard>
                <Cart></Cart>
              </AuthGuard>
              }></Route> 
            <Route path='logout' element={ <Logout></Logout> }></Route>  
            <Route path='*' element={ <Navigate to='/login' replace></Navigate> }></Route>
          </Routes>
          <Footer></Footer> 
        </BrowserRouter>
        </CartProvider>
        </ProductProvider>
      </AuthProvider>
    </>
  )
}
export default App
