import './App.css'
import Header from './component/Header'
import Footer from './component/Footer'
import Products from './component/Products'
import Login from './component/Login'
import Cart from './component/Cart'
import { BrowserRouter, Routes,Route, Navigate } from 'react-router-dom'
import Navbar from './component/Navbar'
import Logout from './component/Logout'
import AuthGuard from './component/AuthGuard'
import AuthProvider from './context/AuthProvider'
import Register from './component/Register'

function App() {
  return (
    <>
      <AuthProvider>
        <BrowserRouter>
          <Header title="MSSU-Mumbai"></Header>
          <Navbar></Navbar>
          <Routes>
            <Route path='login' element={<Login></Login>}></Route>
            <Route path='register' element={<Register></Register> }></Route>  
            <Route path='products' element={<Products></Products>}></Route>  
            <Route path='cart/:name' element={
              <AuthGuard>
                <Cart></Cart>
              </AuthGuard>
              }></Route> 
            <Route path='logout' element={ <Logout></Logout> }></Route>  
            <Route path='*' element={ <Navigate to='/login' replace></Navigate> }></Route>
          </Routes>
          <Footer></Footer> 
        </BrowserRouter>
      </AuthProvider>
    </>
  )
}
export default App
