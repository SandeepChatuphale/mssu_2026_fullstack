
//props passed from Parent Component
//properties are READ-ONLY
function Header(props){
    //we are returning JSX
    return <h1>Ecommerce APP - { props.title }</h1>
}

export default Header