import { useContext, useEffect, useState } from "react"
import { replace, useNavigate, useSearchParams } from "react-router-dom"
import { AuthContext } from "../context/AuthProvider"

const Login = () =>{

    const [username,setUsername] = useState('')
    const [password,setPassword] = useState('')


    const {login} = useContext(AuthContext)

    const navigate = useNavigate();

    const [isValid,setIsValid] = useState(username != '' || password != '')

    //declaring stateful variable using useState()
    //useState uses array-destructuring synatx offered by ES-6
    const [message,setMessage] = useState('Login Pending....')
    const [params] = useSearchParams();
    
    useEffect( () => {
        if(params.get('message'))
            setMessage(params.get('message'))
        else
             setMessage('Login Pending....')
        },[params.get('message')])
    
    const handleFormSubmission = (e) => {
        e.preventDefault(); //prevent default event 
                            //in our case form submission event
    
        //if(username == 'admin' && password == 'admin'){
        if(login(username,password)){
            //message = 'Login Success'
            setMessage('Login Success')//updating stateful variable
            navigate('/products',{replace:true})
        }
        else{
           // message = 'Bad Credentials'
           setMessage("Bad Credentials")//updating stateful variable
        }
    }
    const loginJsx = <form onSubmit={ (e) => handleFormSubmission(e) }>
        <input type="text" placeholder="Username" autoComplete="username"
                           onChange={(e) => {
                                if(e.target.value != ''){
                                   setUsername(e.target.value);
                                    setIsValid(true)
                            }
                            else{
                                setIsValid(false)
                            }
                            }}/><br/>
        <input type="password" placeholder="Password" autoComplete="password"
                               onChange={(e) => setPassword ( e.target.value )}/><br/>
        <input type="submit" disabled={ !isValid }/>
    </form>

    return <>{loginJsx}
                {message}
            </>
}

export default Login