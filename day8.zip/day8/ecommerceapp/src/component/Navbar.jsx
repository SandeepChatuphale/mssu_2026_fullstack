import { useContext, useState } from "react"
import { Link } from "react-router-dom"
import { AuthContext } from "../context/AuthProvider"

const Navbar = () =>{

    const {isLoggedIn} = useContext(AuthContext)

    return(
        <ul>
            { !isLoggedIn && <><li><Link to="login">Login</Link> </li>
                               <li><Link to='register'>Register</Link>  </li>
                             </>
            }
            <li><Link to="products">Products</Link> </li>
            { 
             isLoggedIn && <>
             <li><Link to="cart/sachin">Cart</Link> </li>
             <li><Link to="logout" replace>Logout</Link>  </li> </>
            }
        </ul>
    )
}

export default Navbar