import { useParams } from "react-router-dom"

const Cart = () =>{

    const {name} = useParams();
    //variable
    let username = name

    //{username} - jsx variable

    return(
        <div>
            <h3>Welcome {username}</h3> 
            <h4>Items in Cart</h4>
        </div>
    )
}

export default Cart