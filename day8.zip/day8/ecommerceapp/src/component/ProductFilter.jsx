const ProductFilter = (props)=>{

    const handleFilter =(e)=>{
           //pass data to parent
            props.type(e.target.value)
    }

    return(
        <div>
            Cheaper<input type="radio" name="filter" value={'cheaper'} 
                                       onChange={(e)=> handleFilter(e)} />
            Expensive <input type="radio" name="filter"  value={'expensive'}
                                      onChange={(e)=> handleFilter(e)}/>
            Reset <input type="radio" name="filter"  value={'reset'}
                                      onChange={(e)=> handleFilter(e)}/>
        </div>
    )
}

export default ProductFilter