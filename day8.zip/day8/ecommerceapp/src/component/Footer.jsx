function Footer(){
    return <h4> &copy; 2026 MSSU</h4>
}

export default Footer