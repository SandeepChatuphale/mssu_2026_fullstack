import { createContext, useState } from "react";

export const AuthContext = createContext();

const AuthProvider = (props) =>{

    //used in Navbar to show Links conditionally
    const [isLoggedIn,setIsLoggedIn] = useState(false);

    const registeredUsers = [];

    //used in Register Component
    const register = (username,password) =>{
        registeredUsers.push({username:username,password:password})
        console.log(registeredUsers)
    }

    //used in logout component
    const logout = () =>{
        setIsLoggedIn(false)
    }

    const login = (username,password) =>{
        console.log(username +"     "+password)

        const foundUser = registeredUsers.find( u => u.username == username 
                                                     && u.password == password )
        
        console.log(foundUser)
        if(foundUser){
            setIsLoggedIn(true)
        }
        return foundUser
    }

    return(
        <AuthContext.Provider value={{isLoggedIn:isLoggedIn,register,login,logout}}>
            {props.children}
        </AuthContext.Provider>
    )
}

export default AuthProvider;