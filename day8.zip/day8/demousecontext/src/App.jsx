import { createContext, useState } from 'react'
import './App.css'
import HomeComponent from './HomeComponent'
import ProfileComponent from './ProfileComponent'
import AppProvider from './AppProvider'

function App() {
  return (
    <>
      <AppProvider>
        <HomeComponent></HomeComponent>
        <ProfileComponent></ProfileComponent>
      </AppProvider>
    </>
  )
}

export default App
