import { createContext } from "react";

export const appContext = createContext();
const AppProvider = ({children})=>{

    return(
        <>
            <appContext.Provider value={{theme:'dark'}}>
                {children}
            </appContext.Provider>
        </>
    )
}

export default AppProvider