import { useContext } from "react"
import { appContext } from "./AppProvider";

const HomeComponent = () =>{

    const {theme} = useContext(appContext);
    return <h2> Home {theme} </h2>
}

export default HomeComponent