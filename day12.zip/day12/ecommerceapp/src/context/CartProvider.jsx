import { createContext, useState } from "react";

export const CartContext = createContext();

const CartProvider = (props) => {

    const [cart,setCart] = useState([])

    const addToCart = (p) =>{
        cart.push(p)
        setCart([...cart])
    }
    
    return(
        <CartContext.Provider value={{addToCart,cart}}>
            {props.children}
        </CartContext.Provider>
    )
}

export default CartProvider