import { useContext } from "react";
import { useParams } from "react-router-dom"
import { CartContext } from "../../../context/CartProvider";

const Cart = () =>{

    const {cart} = useContext(CartContext)
    const {name} = useParams();
   
    //use map() function
    const item = cart.map( p => {
        return(
            <tr key={p.id}>
                <td>{p.id}</td>
                <td>{p.name}</td>
                <td>{p.price}</td>
                <td>
                    <button onClick={ () => console.log('===')  }>Delete</button>
                </td>
            </tr>
        )
    })
    if(cart.length > 0){
    return (<>
    <h3>Welcome {name}</h3>
    <h4>Items in Cart</h4>
    <table>
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Name</th>
                    <th>Price</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
                    {item}
                </tbody>
    </table></> )
    }
    else{
        return <h2>Cart is Empty</h2>
    }
}

export default Cart