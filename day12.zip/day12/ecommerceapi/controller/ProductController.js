
let products = [{id:1,name:'tv',price:100},{id:2,name:'phone',price:200}]

export function showAllProducts(req,res){
    res.send(products)
}

export function showProductById(req,res){
    const foundProduct = products.find( p => p.id ==  req.params.productId )
    if(foundProduct)
        res.send(foundProduct)
    else{
        res
            .status(404)
            .send({message:"Product with id " + req.params.productId +" does NOT exist" })
    }
}

export function deleteProductById(req,res) {
    products = products.filter( p => p.id != req.params.productId)
    res
    .status(204)
    .send()
 }

 export function createNewProduct(req,res){
    products.push(req.body)
    res
    .status(201)
    .send(req.body);
}