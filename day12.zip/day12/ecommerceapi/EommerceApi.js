import express, { json } from "express";
import cors from 'cors'
import productRouter from "./route/ProductRoute.js";
import userRouter from "./route/UserRoute.js";
const app = express();

app.use(cors())
app.use(json())

app.use('/products',productRouter)
app.use('/users',userRouter)


app.listen(8080,()=>console.log('server running on 8080'))