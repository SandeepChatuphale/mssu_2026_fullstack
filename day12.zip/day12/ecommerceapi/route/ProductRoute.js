import express from "express";
import { createNewProduct, deleteProductById, showAllProducts, showProductById } from "../controller/ProductController.js";

const productRouter = express.Router();

productRouter.get('',showAllProducts)
productRouter.get('/:productId',showProductById)
productRouter.delete('/:productId',deleteProductById)
productRouter.post('',createNewProduct)

export default productRouter