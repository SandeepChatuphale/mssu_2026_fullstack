import {  useContext, useEffect, useState } from "react"
import { TodoContext } from "../context/TodoProvider"

const Todos = () =>{

    const  {fetchData,todosdata} =  useContext(TodoContext)
    const [todos,setTodos] = useState([])

    useEffect(()=> { setTodos(todosdata) },[todosdata])

    let todosjsx = ''
    if(todos.length > 0){
        
        todosjsx = todos.map(todo =>  (
            <tr key={todo.id}>
                <td>{todo.id}</td>
                <td>{todo.title}</td>
                <td style={{color : todo.completed ? 'green' : 'red'}}>{todo.completed ? 'Yes' : 'no'}</td>
        </tr>
        ))
    }
    else{
        todosjsx = <tr><td colSpan={3}> NO redords </td></tr>
    }
    return <>
        <table>
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Title</th>
                    <th>Completed</th>
                </tr>
            </thead>
            <tbody>
                {todosjsx}
            </tbody>
        </table>
        <button onClick={() => fetchData()}>Fetch Data</button>
    </>;
}

export default Todos