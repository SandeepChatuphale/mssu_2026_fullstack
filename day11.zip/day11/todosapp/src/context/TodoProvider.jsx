import { createContext, useState } from "react"

export const TodoContext = createContext();

const TodoProvider = (props)=>{
    const [todosdata,setTodos] = useState([])

    const  fetchData=async()=>{
        const result = await fetch('https://jsonplaceholder.typicode.com/todos')
        const data = await result.json();
        setTodos(data)
    }

    return(
        <TodoContext.Provider value={{fetchData,todosdata}}>
            {props.children}
        </TodoContext.Provider>
    )
}

export default TodoProvider