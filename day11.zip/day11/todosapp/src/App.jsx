
import './App.css'
import Todos from './component/Todos'
import TodoProvider from './context/TodoProvider'

function App() {

  return (
    <>
      <TodoProvider>
        <Todos></Todos>
      </TodoProvider>
    </>
  )
}

export default App
