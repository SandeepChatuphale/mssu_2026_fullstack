
function read(){
    console.log('read')
}
function write(){
    console.log('write')
}

read();
write();