function greet(){
    console.log('hello')
}
console.log('before')
setTimeout(greet,2000);
console.log('after')

function logout(){
    console.log('Logged out')
    clearInterval(id)
}
//=================================
const id = setInterval(logout,5000);

//=============================

function onfullfilled (){
    console.log('onfullfilled')
}

function onrejected (){
    console.log('onrejected')
}
function onfinally(){
    console.log('finally')
}

let p = new Promise((resolve,reject) => {
    console.log('in promise')
    resolve('')
})
console.log(p)

/*p.then(onfullfilled)
 .catch(onrejected)
 .finally(onfinally) */


