/*function onfullfilled(msg) {
    console.log('onfullfilled ',msg)
}
function onrejected(){
    console.log('in onrejected')
}
function onfinally(){
    console.log('in onfinally')
}
    */
const p = new Promise((resolve,reject)=>{    
   console.log('in side Promise processing order...')
   const result = true;
   if(result){
    resolve('order placed id is ' + 1)//successful completion
   }
   else{
    reject();
   }
})
function placeOrder(){
    return p;
}
async function processOrder(){
   const result =  await placeOrder();
    //take order id and email to user
    console.log(result)
}
processOrder();








/*
console.log('Order placed')
p.then(onfullfilled) //success path
 .catch(onrejected) //error path
 .finally(onfinally) //always executes irrespective of result
//===============================================

p.then(success => console.log(success))
 .catch(error => console.log(error))
 .finally(()=> console.log('in finally'))

*/













