
/*const todosPromise = fetch('https://jsonplaceholder.typicode.com/todos/1')
console.log(todosPromise)

todosPromise.then(success => {
                                console.log(success.status)
                                console.log(success.statusText)
                                const dataPromise = success.json();
                                dataPromise.then( success => console.log(success) )

                             })
*/
//====using async await
async function getData(){
   const result = await fetch('https://jsonplaceholder.typicode.com/todos/1')
   //result.json().then( data => console.log(data)  )
   const data = await result.json();
   console.log(data)
}

getData();
