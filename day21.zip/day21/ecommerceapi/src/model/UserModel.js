import pool from "../config/db.js";

export const login = async(username,password) =>{

    const sql = "SELECT * FROM tbl_user WHERE username = ? AND password = ?";
    const [foundUser] = await pool.query(sql,[username,password])
    return foundUser[0]
}

export const fetchUserRoles = async(username)=>{

    const sql = "SELECT r.roleName FROM tbl_role AS r " +
                "INNER JOIN tbl_user as u ON r.username_fk = u.username " + 
                "WHERE r.username_fk = ?"
    
    const [roles] =  await pool.query(sql,[username]);
    const userRoles = roles.map( role => role.roleName )

    return userRoles
} 

export const findAll = async() =>{
    const sql = "SELECT DISTINCT u.username,u.password, GROUP_CONCAT(r.roleName) AS roles " +
  "FROM tbl_user AS u INNER JOIN tbl_role AS r ON u.username = r.username_fk GROUP BY u.username, u.password";

/*
    const sql = "SELECT DISTINCT u.username,u.password, GROUP_CONCAT(r.roleName SEPARATOR ',') AS roles " +
  "FROM tbl_user AS u INNER JOIN tbl_role AS r ON u.username = r.username_fk GROUP BY u.username, u.password";
*/

  const [users] = await pool.query(sql)
  console.log(users)
  return users
}


export const register = async(username,password) =>{
  try
  {
      const [rows] = await pool.query("INSERT INTO tbl_user VALUES(?,?)",[username,password])
      console.log(rows);
      return rows.affectedRows == 1
  }
  catch(e)
  {
      console.log(e)
      return false
  }
}

export const checkUser = async(username) =>{

  const[foundUser] = await pool.query('SELECT username FROM tbl_user WHERE username = ?',[username])
  console.log(foundUser[0] == undefined,'=============model')
  return foundUser[0] != undefined
}
