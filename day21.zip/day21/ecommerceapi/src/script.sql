CREATE SCHEMA ecommerce_db;

CREATE TABLE `ecommerce_db`.`tbl_product` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NOT NULL,
  `price` FLOAT NOT NULL,
  PRIMARY KEY (`id`));

INSERT INTO `ecommerce_db`.`tbl_product` (`id`, `name`, `price`) VALUES ('1', 'tv', '200');

CREATE TABLE `ecommerce_db`.`tbl_user` (
  `username` VARCHAR(45) NOT NULL,
  `password` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`username`));

  CREATE TABLE `ecommerce_db`.`tbl_role` (
  `roleName` VARCHAR(45) NOT NULL,
  `username_fk` VARCHAR(45) NULL,
  INDEX `uname_fk_idx` (`username_fk` ASC) VISIBLE,
  CONSTRAINT `uname_fk`
    FOREIGN KEY (`username_fk`)
    REFERENCES `ecommerce_db`.`tbl_user` (`username`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);

    INSERT INTO `ecommerce_db`.`tbl_user` (`username`, `password`) VALUES ('a', 'a');

CREATE TABLE tbl_order (
    order_id INT PRIMARY KEY AUTO_INCREMENT,
    username_fk VARCHAR(45) NOT NULL,
    product_id_fk INT NOT NULL,
    quantity INT NOT NULL,
    FOREIGN KEY (username_fk) REFERENCES tbl_user(username),
    FOREIGN KEY (product_id_fk) REFERENCES tbl_product(id)
);
