import express, { json } from "express";
import cors from 'cors'
import cookieParser from "cookie-parser";
import productRouter from "./route/ProductRoute.js";
import userRouter from "./route/UserRoute.js";
import logging from "./middleware/logging.js";
import validation from "./middleware/validation.js";
import validationrule from "./middleware/validationrule.js";
import orderRoute from "./route/OrderRoute.js";
import dotenv from 'dotenv'
import demoRouter from "./route/DemoRoute.js";
dotenv.config()

const app = express();
app.use(cookieParser())
app.use(cors({credentials:true,origin:'http://localhost:5173'}))
app.use(json())
app.use(logging)

//app.use(validationrule)
//app.use(validation)

app.use('/products',productRouter)
app.use('/users',userRouter)
app.use('/orders',orderRoute)
app.use('/demo',demoRouter)

app.listen(process.env.PORT,()=>console.log('server running on ' + process.env.PORT))


export default app