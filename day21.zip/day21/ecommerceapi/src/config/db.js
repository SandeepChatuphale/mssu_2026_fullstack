import { createPool } from "mysql2/promise";
import dotenv from 'dotenv'
dotenv.config()

console.log('process.env.DB_PASSWORD ===>',process.env.DB_PASSWORD)

const pool = createPool({

    /*
    host:'localhost',
    port:3306,
    user:'root',
    password:'root',
    database:'ecommerce_db'
    */

    
    host:process.env.DB_HOST,
    port:process.env.DB_PORT,
    user:process.env.DB_USER,
    password:process.env.DB_PASSWORD,
    database:process.env.DB_NAME

});

export default pool