
import express from "express";
import { getAllOrders } from "../controller/OrderController.js";
import verifytoken from "../middleware/verifytoken.js";
const orderRoute = express.Router();

orderRoute.get("/:username",verifytoken,getAllOrders)

export default orderRoute