import express from "express";
import { authenticate, registerUser, showAllUsers } from "../controller/UserController.js";
import verifytoken from "../middleware/verifytoken.js";
import verifyadminrole from "../middleware/verifyadminrole.js";
const userRouter = express.Router();

userRouter.post('/register',registerUser)
userRouter.post('/authenticate',authenticate)
userRouter.get('',verifytoken,verifyadminrole,showAllUsers)

export default userRouter