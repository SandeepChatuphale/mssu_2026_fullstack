import express from "express";
import { greet } from "../controller/DemoController.js";
const demoRouter = express.Router();

demoRouter.get('',greet)

export default demoRouter
