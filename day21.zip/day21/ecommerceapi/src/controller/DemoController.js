
export const greet = (req,res) =>{
    res
    .status(200)
    .send({message:"Hello"});
}