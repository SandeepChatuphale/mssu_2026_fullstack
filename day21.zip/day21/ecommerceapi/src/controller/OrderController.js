
export const getAllUserOrders = (req,res) => {
    res.send('all User orders')
}


export const getAllOrders = (req,res) => {
    res.send('all orders')
}

export const placeOrder = (req,res) => {
    const order = req.body;
    console.log(order)
    res.send(order)
}
