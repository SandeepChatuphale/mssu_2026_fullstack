import jwt from 'jsonwebtoken'
import { fetchUserRoles, findAll, login,checkUser,register } from '../model/UserModel.js';

let users = []

export function registerUser(req,res){
    console.log('=========register=======',req.body)

        const { username, password} = req.body;
        
        setTimeout(async()=>{
            const foundUser = await checkUser(username);
         
            if(foundUser){
                return res.status(400).send({message:'User already Exists'});
            }
            else{
                const result = await register(username,password);
                if(result){
                    const authenticatedUser = {...req.body}
                    delete authenticatedUser.password
                    return res.status(201).send(authenticatedUser)
                }
                else{
                    return res.status(500).send({message:'Something Went wrong'})
                }
            }
        },5)
}
export async function authenticate(req,res){
    const requestedUser = req.body;

    const foundUser = await login(requestedUser.username,requestedUser.password)

    if(foundUser){

        const roles = await fetchUserRoles(requestedUser.username);
       
        const token = jwt.sign(
                                {username:requestedUser.username,roles},
                                "secretkey",//bad secret key in production
                                {expiresIn:"120s"}
                              )

        res.cookie('jwtcookie',token)
        const authenticatedUser = {username:foundUser.username,roles}
        res.send(authenticatedUser)
    }
    else{
        res.status(404).send({message:'bad credentials'})
    }
}
export async function showAllUsers(req,res){
    const users =  await findAll()
    res
    .status(200)
    .send(users)
}