function add(a,b){
    return a + b
}

describe('USERS API',()=>{
    test('addition test',()=>{
        console.log('test')

        //Arrange (given)
        let a = 10;
        let b = 10;
        let expected = 20;

        //Act (when)
        let actual = add(a,b)

        //Assert (then)
        expect(actual).toBe(expected)        

    })

    it('test2',()=>{
        console.log('test2')
    })

    it.skip('new feature',()=>{
        console.log('testting new feature')
    })

    beforeEach( ()=>{
        console.log('before')
    })

    afterEach( ()=>{
        console.log('after')
    })
})