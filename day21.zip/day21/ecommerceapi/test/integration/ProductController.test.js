import request from 'supertest'
import app from '../../src/EommerceApi.js'

describe('PRODUCTS API',()=>{
    describe("WITHOUT AUTHENTICATION",()=>{
        test('FETCH ALL PRODUCTS',async()=>{
            //Arrange
            const statusCode =200
            const uri = '/products'
            const responseBody = [{id:2,name:"phone",price:100}]

            //Act
            const res = await request(app).get(uri)

            //Assert
            expect(res.statusCode).toBe(statusCode)
            expect(res.body).toEqual(responseBody)
        })

        test('FETCH A PRODUCT BY Id',async()=>{
            //Arrange
            const statusCode = 200
            const uri = '/products/'+2
            const responseBody = {id:2,name:"phone",price:100}

            //Act
            const res = await request(app).get(uri)

            //Assert
            expect(res.statusCode).toBe(statusCode)
            expect(res.body).toEqual(responseBody)
        })
    })
    
})