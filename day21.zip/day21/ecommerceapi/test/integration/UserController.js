import request from 'supertest'
import app from '../src/EommerceApi'


describe('USERS API',()=>{

    describe('WITHOUT AUTHENTICATION',()=>{
    
        test('Register Test should regitser user if non-existing username is given',async()=>{
            
            //Arrange
            const user = {username:"c",password:"c"}
            const uri = '/users/register'
            const statusCode = 201

            //Act
            const res =  await request(app).post(uri)
                                    .send(user)
            
            //Assert
            expect(res.statusCode).toBe(statusCode)
            //expect(res.body).toEqual({username:'bb'})
        
        });

        test('Register Test should NOT regitser user if existing username is given',async()=>{
            
            //Arrange
            const user = {username:"b",password:"b"}
            const uri = '/users/register'
            const statusCode = 400

            //Act
            const res =  await request(app).post(uri)
                                    .send(user)
            
            //Assert
            expect(res.statusCode).toBe(statusCode)
            expect(res.body).toEqual({message:'User already Exists'})
        
        });
    })
    
})
