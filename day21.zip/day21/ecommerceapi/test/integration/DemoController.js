import request from 'supertest'
import app from '../src/EommerceApi'

test('greet test ',async()=>{
    console.log('greet test')

    const res = await request(app).get('/demo')

    expect(res.statusCode).toBe(200)
    expect(res.body).toEqual({"message":"Hello"})


})