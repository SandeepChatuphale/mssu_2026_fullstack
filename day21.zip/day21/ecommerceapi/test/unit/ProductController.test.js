import request from 'supertest'
import app from '../../src/EommerceApi.js'
import { findAll } from '../../src/model/ProductModel.js'
//import { findAll } from "../../src/model/ProductModel.js"


jest.mock('../../src/model/ProductModel.js') 

describe('PRODUCTS API',()=>{
    describe("WITHOUT AUTHENTICATION",()=>{
        test('FETCH ALL PRODUCTS',async()=>{

           // console.log(findAll)    //mocked
            //Arrange
            
            const statusCode =200
            const uri = '/products'
            const responseBody = [{id:2,name:"phone",price:100}]
            findAll.mockReturnValue(responseBody)
            

            //Act
            const res = await request(app).get(uri)

            //Assert
            expect(res.statusCode).toBe(statusCode)
            expect(res.body).toEqual(responseBody)
            
        })
    })
})