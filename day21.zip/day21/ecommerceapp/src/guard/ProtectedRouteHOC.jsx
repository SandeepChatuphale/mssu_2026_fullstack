import { Navigate } from "react-router-dom";

const ProtectedRouteHOC = (WrapperComponent)=>{
    return () =>{
        //hard coded 
        // TODO need to check with read DB from back end
        const isLoggedin = false;

        if(isLoggedin){
            return <WrapperComponent></WrapperComponent>
        }
        else{
            return <Navigate to="/login?message=Please login first" replace></Navigate>
        }
    }
}

export default ProtectedRouteHOC