
import {  Navigate} from "react-router-dom";

const AuthGuard = (props) => {

    //hard coded 
    // TODO need to check with read DB from back end
    const isLoggedin = true;

    if(isLoggedin){
        return <>{props.children}</>
    }
    else{
        return <Navigate to="/login?message=Please login first" replace></Navigate>
    }

   
}

export default AuthGuard