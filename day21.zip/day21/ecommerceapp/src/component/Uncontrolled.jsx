import { useEffect, useRef } from "react"

const Uncontrolled = ()=>{

    const iRef = useRef()

    useEffect(()=>{
        //iRef.current.focus()
    },[])
    const loadData = ()=>{
        //assume this is fetching huge data from server
        iRef.current.showModal()

        setTimeout(()=>{
            iRef.current.close()
        },5000)
    }
    return(
        <>
         {/*<input ref={iRef}></input>*/}
            <dialog ref={iRef}>
                <p>Loading....</p>
            </dialog>
            <button onClick={()=>loadData()}>Load</button>
        </>

    )

}

export default Uncontrolled