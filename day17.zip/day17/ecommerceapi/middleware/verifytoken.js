import jwt from 'jsonwebtoken'
const verifytoken = (req,res,next)=>{

    console.log('in verifytoken middleware')
    //1-fetch cookie
    const token = req.cookies.jwtcookie
    //2-check if token present 
    if(!token){
        //5-else error message
        return res.status(401).send({message:'Token not found '})
    }
    //3-validate token
    const decoded = jwt.verify(token,'secretkey')
    console.log(decoded)

    //4-if validation success
    next()
    
}

export default verifytoken