import { useContext } from "react";
import { appContext } from "./AppProvider";

const ProfileComponent = ()=>{
    const {theme} = useContext(appContext);
    return <h2> Profile {theme}</h2>
}

export default ProfileComponent