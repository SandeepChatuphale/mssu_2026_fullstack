import './Header.css'
//props passed from Parent Component
//properties are READ-ONLY
function Header(props){
    //we are returning JSX
    return <header>Ecommerce APP - { props.title }</header>
}

export default Header