import { useContext } from "react";
import { useNavigate } from "react-router-dom"
import { AuthContext } from "../../../context/AuthProvider";

const Logout = () => {

    const navigate = useNavigate();
    const {logout} = useContext(AuthContext);

    const handleLogout = () =>{
        const r = confirm('are you sure?')
        if(r){
            logout();
            navigate('/login?message=Loggout Successfully',{replace:true})
        }
    }

    return(
        <button onClick={() => handleLogout()}>Logout</button>
    )
}

export default Logout