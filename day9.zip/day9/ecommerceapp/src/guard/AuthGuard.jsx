import { useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";

const AuthGuard = (props) => {

    const navigate = useNavigate();
    //hard coded 
    // TODO need to check with read DB from back end
    const isLoggedin = true;

    if(isLoggedin){
        return <>{props.children}</>
    }
    else{
        useEffect(() => {navigate("/login?message=Please login first",{replace:true});},[])
    }

    return <></>
   
}

export default AuthGuard