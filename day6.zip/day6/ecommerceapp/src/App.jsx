import './App.css'
import Header from './Header'
import Footer from './Footer'
import Products from './Products'
import Login from './Login'
import Cart from './Cart'
import { BrowserRouter, Routes,Route, Navigate } from 'react-router-dom'
import Navbar from './Navbar'
import Logout from './Logout'
import AuthGuard from './AuthGuard'

function App() {
  return (
    <>
      <BrowserRouter>
        <Header title="MSSU-Mumbai"></Header>
        <Navbar></Navbar>
        <Routes>
          <Route path='login' element={<Login></Login>}></Route>  
          <Route path='products' element={<Products></Products>}></Route>  
          <Route path='cart/:name' element={
            <AuthGuard>
              <Cart></Cart>
            </AuthGuard>
            }></Route> 
          <Route path='logout' element={ <Logout></Logout> }></Route>  
          <Route path='*' element={<Navigate to="/login" replace />}></Route>
        </Routes>
        <Footer></Footer> 
      </BrowserRouter>
    </>
  )
}
export default App
